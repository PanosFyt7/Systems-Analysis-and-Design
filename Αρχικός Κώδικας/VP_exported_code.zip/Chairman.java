public class Chairman extends User {

	private boolean Voted;

	public boolean getVoted() {
		// TODO - implement Chairman.getVoted
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Voted
	 */
	public void setVoted(boolean Voted) {
		// TODO - implement Chairman.setVoted
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ProtocolNum
	 */
	public void CheckForInterest(int ProtocolNum) {
		// TODO - implement Chairman.CheckForInterest
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ProtocolNum
	 */
	public boolean setChosen(int ProtocolNum) {
		// TODO - implement Chairman.setChosen
		throw new UnsupportedOperationException();
	}

}