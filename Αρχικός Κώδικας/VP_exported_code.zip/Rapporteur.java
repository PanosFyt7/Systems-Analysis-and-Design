public class Rapporteur extends Member {

	private boolean ChosenForSuggestion;

}