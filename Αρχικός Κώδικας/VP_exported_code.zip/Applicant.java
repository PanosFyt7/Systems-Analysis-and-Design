public class Applicant extends User {

	private ArrayList ApplicationList;

	/**
	 * 
	 * @param UserID
	 * @param SubjectOfResearch
	 * @param AttachedFiles
	 * @param ResearchTeamIDs
	 */
	public Application Submit(int UserID, string SubjectOfResearch, ArrayList AttachedFiles, ArrayList ResearchTeamIDs) {
		// TODO - implement Applicant.Submit
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Application
	 */
	public void addApplicationToMyList(Application Application) {
		// TODO - implement Applicant.addApplicationToMyList
		throw new UnsupportedOperationException();
	}

	public ArrayList getApplicationList() {
		// TODO - implement Applicant.getApplicationList
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ApplicationList
	 */
	public void setApplicationList(ArrayList ApplicationList) {
		// TODO - implement Applicant.setApplicationList
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ProtocolNum
	 */
	public void download(int ProtocolNum) {
		// TODO - implement Applicant.download
		throw new UnsupportedOperationException();
	}

}