public class Member_Catalog {

	private Member Members;

}