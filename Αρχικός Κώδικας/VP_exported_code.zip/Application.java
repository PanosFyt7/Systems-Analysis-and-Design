public class Application {

	private int ProtocolNum;
	private string FolderName;
	private ArrayList AttachedFiles;
	private string SubjectOfResearch;
	private int ApplicantID;
	private ArrayList ReseachTeamIDs;
	private string Status;

	/**
	 * 
	 * @param ProtocolNum
	 * @param AttachedFiles
	 * @param SubjectOfResearch
	 * @param ApplicantID
	 * @param ResearchTeamIDs
	 */
	public void addApplication(int ProtocolNum, ArrayList AttachedFiles, string SubjectOfResearch, int ApplicantID, ArrayList ResearchTeamIDs) {
		// TODO - implement Application.addApplication
		throw new UnsupportedOperationException();
	}

	public int getProtocolNum() {
		// TODO - implement Application.getProtocolNum
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ProtocolNum
	 */
	public void setProtocolNum(int ProtocolNum) {
		// TODO - implement Application.setProtocolNum
		throw new UnsupportedOperationException();
	}

	public string getFolderName() {
		// TODO - implement Application.getFolderName
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param FolderName
	 */
	public void setFolderName(string FolderName) {
		// TODO - implement Application.setFolderName
		throw new UnsupportedOperationException();
	}

	public ArrayList getAttachedFiles() {
		// TODO - implement Application.getAttachedFiles
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param AttachedFiles
	 */
	public void setAttachedFiles(ArrayList AttachedFiles) {
		// TODO - implement Application.setAttachedFiles
		throw new UnsupportedOperationException();
	}

	public string getSubjectOfResearch() {
		// TODO - implement Application.getSubjectOfResearch
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param SubjectOfResearch
	 */
	public void setSubjectOfResearch(string SubjectOfResearch) {
		// TODO - implement Application.setSubjectOfResearch
		throw new UnsupportedOperationException();
	}

	public int getApplicantID() {
		// TODO - implement Application.getApplicantID
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ApplicantID
	 */
	public void setApplicantID(int ApplicantID) {
		// TODO - implement Application.setApplicantID
		throw new UnsupportedOperationException();
	}

	public ArrayList getReseachTeamIDs() {
		// TODO - implement Application.getReseachTeamIDs
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ReseachTeamIDs
	 */
	public void setReseachTeamIDs(ArrayList ReseachTeamIDs) {
		// TODO - implement Application.setReseachTeamIDs
		throw new UnsupportedOperationException();
	}

	public string getStatus() {
		// TODO - implement Application.getStatus
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Status
	 */
	public void setStatus(string Status) {
		// TODO - implement Application.setStatus
		throw new UnsupportedOperationException();
	}

}