public class FinalDecision {

	private string Verdict;
	private string Text;
	private int ProtocolNum;
	private ArrayList EvaluatorsList;

	public string getVerdict() {
		// TODO - implement FinalDecision.getVerdict
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Verdict
	 */
	public void setVerdict(string Verdict) {
		// TODO - implement FinalDecision.setVerdict
		throw new UnsupportedOperationException();
	}

	public string getText() {
		// TODO - implement FinalDecision.getText
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Text
	 */
	public void setText(string Text) {
		// TODO - implement FinalDecision.setText
		throw new UnsupportedOperationException();
	}

	public int getProtocolNum() {
		// TODO - implement FinalDecision.getProtocolNum
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ProtocolNum
	 */
	public void setProtocolNum(int ProtocolNum) {
		// TODO - implement FinalDecision.setProtocolNum
		throw new UnsupportedOperationException();
	}

	public ArrayList getEvaluatorsList() {
		// TODO - implement FinalDecision.getEvaluatorsList
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param EvaluatorsList
	 */
	public void setEvaluatorsList(ArrayList EvaluatorsList) {
		// TODO - implement FinalDecision.setEvaluatorsList
		throw new UnsupportedOperationException();
	}

}