public class Evaluation {

	private string Verdict;
	private string Text;
	private int ProtocolNum;
	private int UserID;

	public string getVerdict() {
		// TODO - implement Evaluation.getVerdict
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Verdict
	 */
	public void setVerdict(string Verdict) {
		// TODO - implement Evaluation.setVerdict
		throw new UnsupportedOperationException();
	}

	public string getText() {
		// TODO - implement Evaluation.getText
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Text
	 */
	public void setText(string Text) {
		// TODO - implement Evaluation.setText
		throw new UnsupportedOperationException();
	}

	public int getProtocolNum() {
		// TODO - implement Evaluation.getProtocolNum
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ProtocolNum
	 */
	public void setProtocolNum(int ProtocolNum) {
		// TODO - implement Evaluation.setProtocolNum
		throw new UnsupportedOperationException();
	}

	public int getUserID() {
		// TODO - implement Evaluation.getUserID
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param UserID
	 */
	public void setUserID(int UserID) {
		// TODO - implement Evaluation.setUserID
		throw new UnsupportedOperationException();
	}

}