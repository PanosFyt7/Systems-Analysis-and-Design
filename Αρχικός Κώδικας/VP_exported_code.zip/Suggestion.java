public class Suggestion {

	private string text;
	private string RapporteurName;
	private int ProtocolNum;
	private int UserID;

	public string getText() {
		return this.text;
	}

	/**
	 * 
	 * @param text
	 */
	public void setText(string text) {
		this.text = text;
	}

	public string getRapporteurName() {
		// TODO - implement Suggestion.getRapporteurName
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param RapporteurName
	 */
	public void setRapporteurName(string RapporteurName) {
		// TODO - implement Suggestion.setRapporteurName
		throw new UnsupportedOperationException();
	}

	public int getProtocolNum() {
		// TODO - implement Suggestion.getProtocolNum
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ProtocolNum
	 */
	public void setProtocolNum(int ProtocolNum) {
		// TODO - implement Suggestion.setProtocolNum
		throw new UnsupportedOperationException();
	}

	public int getUserID() {
		// TODO - implement Suggestion.getUserID
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param UserID
	 */
	public void setUserID(int UserID) {
		// TODO - implement Suggestion.setUserID
		throw new UnsupportedOperationException();
	}

}