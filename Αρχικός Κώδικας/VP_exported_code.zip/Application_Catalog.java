public class Application_Catalog {

	private Application Applications;

}