public class User {

	private int UserID;
	private string Username;
	private string Password;
	private string Name;

	/**
	 * 
	 * @param username
	 * @param password
	 */
	public boolean login(string username, string password) {
		// TODO - implement User.login
		throw new UnsupportedOperationException();
	}

	public void getEmail() {
		// TODO - implement User.getEmail
		throw new UnsupportedOperationException();
	}

	public int getUserID() {
		// TODO - implement User.getUserID
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param UserID
	 */
	public void setUserID(int UserID) {
		// TODO - implement User.setUserID
		throw new UnsupportedOperationException();
	}

	public string getUsername() {
		// TODO - implement User.getUsername
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Username
	 */
	public void setUsername(string Username) {
		// TODO - implement User.setUsername
		throw new UnsupportedOperationException();
	}

	public string getPassword() {
		// TODO - implement User.getPassword
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Password
	 */
	public void setPassword(string Password) {
		// TODO - implement User.setPassword
		throw new UnsupportedOperationException();
	}

	public string getName() {
		// TODO - implement User.getName
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Name
	 */
	public void setName(string Name) {
		// TODO - implement User.setName
		throw new UnsupportedOperationException();
	}

}