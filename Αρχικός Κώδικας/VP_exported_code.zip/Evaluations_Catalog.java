public class Evaluations_Catalog {

	private Evaluation Evauations;

}