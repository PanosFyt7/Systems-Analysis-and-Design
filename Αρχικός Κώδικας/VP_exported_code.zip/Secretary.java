public class Secretary extends User {

	/**
	 * 
	 * @param FolderName
	 */
	public void completenessCheck(string FolderName) {
		// TODO - implement Secretary.completenessCheck
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param FolderName
	 */
	public void protocol(string FolderName) {
		// TODO - implement Secretary.protocol
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ProtocolNum
	 */
	public void View(int ProtocolNum) {
		// TODO - implement Secretary.View
		throw new UnsupportedOperationException();
	}

}